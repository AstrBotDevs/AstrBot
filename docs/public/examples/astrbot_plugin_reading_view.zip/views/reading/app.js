const list = document.querySelector("#books");
const empty = document.querySelector("#empty");
const progress = document.querySelector("#progress");
const status = document.querySelector("#status");
const form = document.querySelector("#add-form");
const addToggle = document.querySelector("#add-toggle");
const title = document.querySelector("#title");
const author = document.querySelector("#author");
let books = [];
let activeFilter = "all";
let pending = false;
let view;

function render() {
  const focusedId =
    document.activeElement?.closest("[data-book-id]")?.dataset.bookId;
  const read = books.filter((book) => book.read).length;
  progress.replaceChildren();
  const count = document.createElement("strong");
  count.textContent = `${read} / ${books.length}`;
  progress.append(count, " 本已读");
  document.querySelector("#count-all").textContent = books.length;
  document.querySelector("#count-read").textContent = read;
  document.querySelector("#count-unread").textContent = books.length - read;
  const visible = books.filter(
    (book) => activeFilter === "all" || book.read === (activeFilter === "read"),
  );
  list.replaceChildren();
  for (const book of visible) {
    const row = document.createElement("li");
    row.className = "book-row";
    const number = document.createElement("span");
    number.className = "number";
    number.setAttribute("aria-hidden", "true");
    number.textContent = String(books.indexOf(book) + 1).padStart(2, "0");
    const spine = document.createElement("span");
    spine.className = "spine";
    spine.setAttribute("aria-hidden", "true");
    const copy = document.createElement("div");
    copy.className = "book-copy";
    const heading = document.createElement("h2");
    heading.className = "book-title";
    heading.textContent = book.title;
    const byline = document.createElement("p");
    byline.className = "book-author";
    byline.textContent = book.author || "未填写作者";
    copy.append(heading, byline);
    const button = document.createElement("button");
    button.type = "button";
    button.className = "read-button";
    button.dataset.bookId = book.id;
    button.setAttribute("aria-pressed", String(book.read));
    button.setAttribute(
      "aria-label",
      `将《${book.title}》标记为${book.read ? "待读" : "已读"}`,
    );
    button.disabled = pending;
    button.innerHTML =
      '<span></span><svg viewBox="0 0 16 16" aria-hidden="true" fill="none"><path d="m3 8 3 3 7-7" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"/></svg>';
    button.querySelector("span").textContent = book.read ? "已读" : "标记已读";
    row.append(number, spine, copy, button);
    list.append(row);
  }
  empty.hidden = visible.length !== 0;
  empty.textContent =
    activeFilter === "read" ? "还没有标记为已读的书。" : "没有待读书目。";
  addToggle.hidden = !form.hidden || books.length >= 20;
  if (focusedId) {
    const previous = [...list.querySelectorAll("button")].find(
      (button) => button.dataset.bookId === focusedId,
    );
    (
      previous || document.querySelector(`[data-filter="${activeFilter}"]`)
    )?.focus({ preventScroll: true });
  }
}

document.querySelectorAll("[data-filter]").forEach((button) => {
  button.onclick = () => {
    activeFilter = button.dataset.filter;
    document
      .querySelectorAll("[data-filter]")
      .forEach((item) =>
        item.setAttribute("aria-pressed", String(item === button)),
      );
    render();
  };
});

addToggle.onclick = () => {
  form.hidden = false;
  addToggle.hidden = true;
  addToggle.setAttribute("aria-expanded", "true");
  title.focus();
};
document.querySelector("#cancel").onclick = () => {
  form.hidden = true;
  addToggle.hidden = false;
  addToggle.setAttribute("aria-expanded", "false");
  status.textContent = "";
  addToggle.focus();
};
form.addEventListener("keydown", (event) => {
  if (event.key === "Escape" && !pending)
    document.querySelector("#cancel").click();
  if (
    event.key === "Enter" &&
    event.target.matches("input") &&
    !event.isComposing
  ) {
    event.preventDefault();
    if (!pending) document.querySelector("#save").click();
  }
});

list.onclick = async (event) => {
  const button = event.target.closest("button[data-book-id]");
  if (!button || pending || !view) return;
  const book = books.find((item) => item.id === button.dataset.bookId);
  pending = true;
  status.textContent = "正在保存…";
  status.dataset.error = "false";
  render();
  try {
    await view.action("reading_view:set_read", {
      book_id: book.id,
      read: !book.read,
    });
    status.textContent = "已保存";
  } catch (error) {
    status.dataset.error = "true";
    status.textContent =
      error.code === "REVISION_CONFLICT"
        ? "清单已在其他地方更新，请重试。"
        : "未能保存，请稍后重试。";
  } finally {
    pending = false;
    render();
    const next = [...list.querySelectorAll("button")].find(
      (item) => item.dataset.bookId === book.id,
    );
    (next || document.querySelector(`[data-filter="${activeFilter}"]`))?.focus({
      preventScroll: true,
    });
  }
};

document.querySelector("#save").onclick = async (event) => {
  event.preventDefault();
  if (pending || !view) return;
  const name = title.value.trim();
  status.dataset.error = "true";
  if (!name) {
    status.textContent = "先填一下书名。";
    title.focus();
    return;
  }
  if (
    books.some(
      (book) => book.title.toLocaleLowerCase() === name.toLocaleLowerCase(),
    )
  ) {
    status.textContent = "这本书已经在清单中了。";
    title.focus();
    return;
  }
  pending = true;
  status.dataset.error = "false";
  status.textContent = "正在保存…";
  form.querySelectorAll("input, button").forEach((element) => {
    element.disabled = true;
  });
  render();
  try {
    await view.action("reading_view:add_book", {
      title: name,
      author: author.value.trim(),
    });
    form.reset();
    form.hidden = true;
    addToggle.setAttribute("aria-expanded", "false");
    document.querySelector('[data-filter="all"]').click();
    status.textContent = "已加入清单";
  } catch {
    status.dataset.error = "true";
    status.textContent = "未能添加，请稍后重试。";
  } finally {
    pending = false;
    form.querySelectorAll("input, button").forEach((element) => {
      element.disabled = false;
    });
    render();
    if (form.hidden) addToggle.focus();
  }
};

try {
  const bridge = window.AstrBotPluginView;
  await bridge.ready();
  view = bridge.view;
  view.subscribe(({ data }) => {
    books = data.books;
    render();
  });
} catch (error) {
  console.error("Reading view initialization failed:", error);
  status.dataset.error = "true";
  status.textContent = "阅读清单初始化失败，请刷新页面重试。";
  addToggle.disabled = true;
}
