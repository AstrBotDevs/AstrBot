"""A small reading list demonstrating command and tool-created ChatUI views."""

from pathlib import Path
from uuid import uuid4

from pydantic import BaseModel, ConfigDict, Field

from astrbot.api import chatui
from astrbot.api.event import AstrMessageEvent, filter
from astrbot.api.star import Star


class SetReadInput(BaseModel):
    """Validated reading-status change."""

    model_config = ConfigDict(extra="forbid", strict=True)
    book_id: str = Field(min_length=1, max_length=64)
    read: bool


class AddBookInput(BaseModel):
    """Validated book details entered in the card."""

    model_config = ConfigDict(extra="forbid", strict=True, str_strip_whitespace=True)
    title: str = Field(min_length=1, max_length=80)
    author: str = Field(default="", max_length=48)


class ReadingViewPlugin(Star):
    """Provide an independent, persistent reading list in each chat card."""

    chatui_views = [
        chatui.ViewSpec(
            name="reading",
            entry=Path("views/reading/index.html"),
            target="chat_message",
            version=1,
            actions=["reading_view:set_read", "reading_view:add_book"],
        ),
    ]

    @filter.command("reading", alias={"书单"})
    async def reading(self, event: AstrMessageEvent):
        """Open a reading list directly from a command.

        Args:
            event: Incoming command event.

        Yields:
            A new interactive reading-list card.
        """
        yield await self.open_reading_list(event)

    @filter.llm_tool(name="open_reading_list")
    async def open_reading_list(self, event: AstrMessageEvent):
        """Open an interactive reading list when the user asks for a book list or reading tracker.

        Returns:
            A new reading-list card with sample books and a text fallback.
        """
        return event.view_result(
            name="reading",
            text="阅读清单已创建。待读：设计心理学、看不见的城市；已读：悉达多。可在卡片中添加书目、标记已读。",
            data={
                "books": [
                    {
                        "id": "design",
                        "title": "设计心理学",
                        "author": "唐纳德·诺曼",
                        "read": False,
                    },
                    {
                        "id": "cities",
                        "title": "看不见的城市",
                        "author": "伊塔洛·卡尔维诺",
                        "read": False,
                    },
                    {
                        "id": "siddhartha",
                        "title": "悉达多",
                        "author": "赫尔曼·黑塞",
                        "read": True,
                    },
                ],
            },
        )

    @filter.ui_action("reading_view:set_read")
    async def set_read(self, event: AstrMessageEvent):
        """Set a book's reading status without invoking the model.

        Args:
            event: Authenticated card interaction.

        Yields:
            A replacement snapshot of the current card.

        Raises:
            ValueError: If the book does not belong to this card.
        """
        interaction = event.get_ui_interaction()
        if interaction is None:
            return
        payload = SetReadInput.model_validate(interaction.data)
        books = interaction.view.data["books"]
        if not any(book["id"] == payload.book_id for book in books):
            raise ValueError("The selected book is not in this reading list.")
        yield event.view_result(
            data={
                "books": [
                    {**book, "read": payload.read}
                    if book["id"] == payload.book_id
                    else book
                    for book in books
                ],
            }
        )

    @filter.ui_action("reading_view:add_book")
    async def add_book(self, event: AstrMessageEvent):
        """Append a book to the current card.

        Args:
            event: Authenticated card interaction.

        Yields:
            A replacement snapshot including the new book.

        Raises:
            ValueError: If the list is full or already contains the title.
        """
        interaction = event.get_ui_interaction()
        if interaction is None:
            return
        payload = AddBookInput.model_validate(interaction.data)
        books = interaction.view.data["books"]
        if len(books) >= 20:
            raise ValueError("This reading list already contains 20 books.")
        if any(book["title"].casefold() == payload.title.casefold() for book in books):
            raise ValueError("This title is already in the reading list.")
        yield event.view_result(
            data={
                "books": [
                    *books,
                    {
                        "id": uuid4().hex,
                        "title": payload.title,
                        "author": payload.author,
                        "read": False,
                    },
                ],
            }
        )
